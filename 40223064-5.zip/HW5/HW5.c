//negar kazemi    40223064

#include <stdio.h>
#include <string.h>
 int main()
 {
    int n,i,j;
    printf("please enter n\n");
    scanf("%d",&n);
    printf("enter your phrase\n");
    char a[n+1];
    scanf("%s",a);
    for ( i=0; i<=n; i++)
    {
        if (a[i]==a[i+1])
        {
            a[i]='\0';
            printf("%s",a);
            for(j=i+2; j<=n; j++)
                printf("%c",a[j]);
            printf("\n");
           
        }
       
    }
 }
